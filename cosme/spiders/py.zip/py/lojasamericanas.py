{\rtf1\ansi\ansicpg1252\cocoartf1138\cocoasubrtf510
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\f0\fs36 \cf0 IMAGE = "//img[@id='imgProduto']/@src"\
NAME =  "//h1[@class=\\'title\\']/strong[@class=\\'n name fn\\']/text()"\
BRAND = "//div[@class=\\'infoProd\\']/dl/dd[1]/text()"\
PRICE = "//span[@class=\\'amount\\']/text()"\
STARS="//div[@id=\\'BVRRRatingSummaryNoReviewsWriteImageLinkID\\']/a/img/@src"\
DESCRIPTION = "//div[@class=\\'infoProd\\']/p/text()"\
CATEGORY="//a[@class=\\'link\\']/text()"\
SKU="//span[@class=\\'id\\']/text()"\
lojasamericanas.py }