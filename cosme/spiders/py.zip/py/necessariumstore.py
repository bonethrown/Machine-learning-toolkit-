{\rtf1\ansi\ansicpg1252\cocoartf1138\cocoasubrtf510
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardeftab720\pardirnatural

\f0\fs36 \cf0 IMAGE =  "//a[@class=\\'cboxElement\\']/img/@src"\
NAME =  "//div[@class=\\'texto_cabecalho_pagina\\']/h1/text()"\
BRAND = "//li[@class=\\'produto_fabricante\\']/a[@class=\\'hiperlink\\']/text()"\
PRICE = "//td[@id=\\'produto_preco\\']/text()"\
STARS="//null"\
DESCRIPTION = "//null"\
CATEGORY="//div[@id=\\'breadcrumb\\']/a[4]/span/text()"\
SKU="//span[@id=\\'produto_cod_ref\\']/text()"\
necessariumstore.py (END)\
}