{\rtf1\ansi\ansicpg1252\cocoartf1138\cocoasubrtf510
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardeftab720\pardirnatural

\f0\fs36 \cf0 IMAGE = "//img[@id=\\'ctl00_PlaceHolderMain_HostWebPart5_ctl00_imgFoto\\']/@src"\
NAME =  "//span[@id=\\'ctl00_m_g_5959861e_a361_40b0_8190_b86d4ac8cef7_ctl00_lblTituloProduto\\']/text()"\
BRAND = "//null"\
PRICE = "//span[@id=\\'ctl00_m_g_5959861e_a361_40b0_8190_b86d4ac8cef7_ctl00_lblPorValorReal\\']/text()"\
STARS="//img[@id=\\'ctl00_m_g_b75dfbca_15b6_46ad_b887_c7fc3a433b84_ctl00_imgProductRating\\']/@src"\
DESCRIPTION = "//span[@id=\\'ctl00_m_g_5959861e_a361_40b0_8190_b86d4ac8cef7_ctl00_updatePanel\\']/div[@class=\\'divDescricaoProduto\\']/text()"\
CATEGORY="//h2[@class=\\'titBox\\']/span/text()"\
SKU="//null"\
boticario.py (END)\
}