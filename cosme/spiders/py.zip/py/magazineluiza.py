{\rtf1\ansi\ansicpg1252\cocoartf1138\cocoasubrtf510
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww14260\viewh9480\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\f0\fs36 \cf0 IMAGE = "//div[@class=\\'big-picture-first-image\\']/a/img/"\
NAME =  "//div[@class='container-title-product-detail']/h1/text()"\
BRAND = "//div[@class=\\'fs-row\\'][1]/div[@class=\\'fs-right\\']/div[1]/p/text()" \
PRICE = "//span[@class=\\'right-price\\']/strong/text()"\
STARS="//null\
DESCRIPTION = "//strong[@class='fs-presentation']/text()"\
CATEGORY="//li[4]/a[@class=\\'last\\']/text()"\
SKU="//div[@class=\\'container-title-product-detail\\']/small/text()"\
magazineluiza.py (END)}